// var keyword
var a=10
console.log(a)


var name="ABDUL REHAMAN"
console.log(name)

// let keyword
let x;
let y;
console.log(x,y)


let d = null;
let c = null;
console.log(d)


var bool =true
console.log(bool)


let j=Infinity
console.log(j)
console.log(typeof(j))
console.log(Boolean(j))

let ab=1.2345
let ac=2.3456
console.log(ab+ac)

// const keyword
const date = new Date("2025-10-28");
console.log(date)



// Type of operator

console.log(typeof(a))
console.log(typeof(d))
console.log(typeof(bool))
console.log(typeof(ab))


// functions
// function decleration

function add(q,w)
{
    return q+w;
    
}
console.log(add(10,20));


function ap(b,f)
{
    return b*f;
}
console.log(ap(9,8))


// function expresssion
let fun=function (r,t)
{
    return r+t;
}
console.log(fun(100,200))


let dd=function (g,h)
{
    return g-h;
}
console.log(dd(100,70))



// Arrow function
let b=(u,i) =>
{
    return u+i;
}
console.log(b(300,500))


let ad=(m,n) => m+n;
console.log(ad(100,400))

