// object
let av={          
    car :"BMW",
    cost : 1200,
    mailage :1.78,
}
console.log(av)


function emp(car)
{
    console.log(car)
}


let c1={
    bus:1300,
    price:5.7,
    mailage:4.6
}

emp(c1)


const pp = {firstName:"Abdul", lastName:"Rehaman"};
console.log(pp.firstName + " " + pp.lastName)


const pe = {
        firstName: "John",
        lastName: "Doe",
        age: 30
        };
   console.log(pe)   
 


// Array object
const cars = ["Saab", "Volvo", "BMW"];
console.log(cars)

// Date object
const date = new Date("2025-10-31");
console.log(date)


// arthematic operators(+,-,*,/,%,++,--)

// addition
let num1=1234
let num2=567
console.log(num1+num2)

// subtraction
let at=98765
let ar=2345
console.log(at-ar)

// multiple
let ac=12
let ad=5
console.log(ac*ad)

// divison
let ba=100
let ca=5
console.log(ba/ca)

// remainder
let x = 5;
let y = 2;
let z = x % y;
console.log(z)

// increment
let G = 5;
G++;
let H = G;
console.log(G)

// decrement
let I=5;
I--;
let J=I;
console.log(J)


//    comparsion operators(==,===,!==,!=)

// ==
let age=18
console.log(age==18)

let username ="Abdul"
let name="abdul"
console.log(username == name)

let haspasswort="true"
console.log(haspasswort=true)

// ===
let A=5
let B='5'
console.log(A===B)

console.log(true===1)

// !==
let C=10
let D=10
console.log(C!==D)

let E=5
let F='5'
console.log(E !== F)

// !=
let K=10
let L=6
console.log(K!=L)

// <
let text1 = "2";
let text2 = "8";
let result = text1 < text2;
console.log(result)

// <
let text = "2";
let tex = "8";
let res = text > tex;
console.log(res)





