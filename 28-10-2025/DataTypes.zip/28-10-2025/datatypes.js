// int myNum = 5;               // Integer (whole number)
// float myFloatNum = 5.99f;    // Floating point number
// char myLetter = 'D';         // Character
// boolean myBool = true;       // Boolean
// String myText = "Hello";     // String

// string
var name='Abdul'
var secondname='Rehaman'
console.log(name+secondname)

var em='web'
var tm='development'
console.log(em+tm)

// integers
// addition
let num1=1234
let num2=567
console.log(num1+num2)

// subtraction
let at=98765
let ar=2345
console.log(at-ar)

// multiple
let ac=12
let ad=5
console.log(ac*ad)

// divison
let ba=100
let ca=5
console.log(ba/ca)

let t = 250;
let z = 40.5;
    console.log("Value of x=" + t);
    console.log("Value of y=" + z);

// float
let a=12.5676
let b=43663.526253
console.log(a+b)

// boolean
var ab=true
console.log(ab)

// Outputs: undefined
let u;
console.log(u); 

// Biginit
let hugeNumber = 9007199254740991n;
let anotherHugeNumber = BigInt("12345678901234567890");
console.log(hugeNumber+anotherHugeNumber)

// Object
const person = {firstName:"John", lastName:"Doe"};
console.log(person.firstName + " " + person.lastName)

// Array object
const cars = ["Saab", "Volvo", "BMW"];
console.log(cars)

// Date object
const date = new Date("2025-10-28");
console.log(date)

// Undefined
let x;
let y;
console.log(x,y)

// Null
let d = null;
let c = null;
console.log(d,c)

// Symbol
const e = Symbol();
 f = Symbol();
 console.log(e,f)




 
