// // primitive datatypes

// Number

let a=123;
console.log(a)

let b=23;
console.log(b)

// string

var name='Abdul Rehaman'
console.log(name)

var em="web Development"
console.log(em)

var c=`Abdul`
console.log(c)

// Boolean

var ab=true
console.log(ab)

var d=false
console.log(d)

// undefined

let e;
console.log(e)

let f;
let g;
console.log(f,g)

// Null

let h=null;
console.log(h)

// Type of operator

console.log(typeof(a))
console.log(typeof(e))
console.log(typeof(h))
console.log(typeof(name))
console.log(typeof(ab))

