import h from './index.js'

console.log(h)


export default function good(){
    
}


import {hello} from './index.js'

console.log(hello)

import {name,age} from './index.js'

console.log(name,age)

