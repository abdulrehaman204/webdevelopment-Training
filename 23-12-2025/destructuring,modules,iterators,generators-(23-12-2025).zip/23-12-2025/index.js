// module

import good from './index1.js'

console.log(good)

function abdul(a,b){
   return a+b;
}

console.log(abdul(10,20))



export default function hey(){
  
}


export function hello(){

}


export var name="abdul";
export let age = 10;




// exporting the file in 2 ways 
// default  (only one export can be done)(we can import with any name)
// named   (n no.of exports)