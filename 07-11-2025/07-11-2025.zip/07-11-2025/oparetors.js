//    comparsion operators(==,===,!==,!=,<,>,<=,>=)

// == (compare 2 values)
let a=10;
let b=8;
console.log(a==b)


let c=100;
let d=100;
console.log(c==d)


let e="5"
let f=5
console.log(e==f)


let username ="Abdul"
let name="abdul"
console.log(username == name)


let haspasswort="true"
console.log(haspasswort=true)


// === (compare both values and data types)
let g=10;
let h=10;
console.log(g===h)


let i=100;
let j="100";
console.log(i===j)


console.log(true===1)


// !== (it compares both values and data types are equal or not)
let C=10
let D=10
console.log(C!==D)


let E=5
let F='5'
console.log(E !== F)


// != (it compares the 2 values are equal or not)
let K=10
let L=6
console.log(K!=L)


let M=100;
let N='100';
console.log(M!=N)


// < (less than)
let text1 = "2";
let text2 = "8";
let result = text1 < text2;
console.log(result)


// > (greater than)
let text = "2";
let tex = "8";
let res = text > tex;
console.log(res)


// <= (it compares less than and equal to)
let k=200;
let l=300;
console.log(k<=l)


let m=300;
let n=300;
console.log(m<=n)


// >= (it compares greater than and equal to)
let o=500;
let p=200;
console.log(o>=p)


let q=600;
let r=700;
console.log(q>=r)


// assignment operators (=,+=,-=,*=,**=,/=,%=,)

// = (The Simple Assignment Operator assigns a simple value to a variable.)
let x=20;
let y=x;
console.log(y)

let z=10;
let w=30+z;
console.log(w)

let xy=500;
let yz=100;
console.log(xy=yz)

// += The Addition Assignment Operator adds a value to a variable.
let v=40;
v +=10;
console.log(v)

let u=100;
u+=20;
console.log(u)

let uv=200;
uv +=50;
console.log(uv)

// -= The Subtraction Assignment Operator subtracts a value from a variable.
let t=50;
t -=10;
console.log(t)

let s=80;
s -=20;
console.log(s)

// *= The Multiplication Assignment Operator multiplies a variable.
let R=200;
R *=5;
console.log(R)

let S=500;
S *=10;
console.log(S)

// **= The Exponentiation Assignment Operator raises a variable to the power of the operand.
let P=10;
P **=5;
console.log(P)

let O=10;
let Q=20;
console.log(O**=Q)


let pn=15;
pn **=5;
console.log(pn)

// /= The Division Assignment Operator divides a variable.
let U=100;
U /=5;
console.log(U)

let G=400;
let H=200;
console.log(G/=H)



// logical operators (it performes logical operations)

// && (both conditions are true)
console.log(10>5 && 12>30)

console.log(25<30 && 30>20)


// OR (any one condition is true)
console.group(10>7 || 15>40)

console.log(20<50 || 30>50)

console.log(100<20 || 100<50)


// NOT ! 
console.log(!(10>=10))

console.log(!(100>50))



// Ternary operator 
let age=11;
age>=18 ? console.log("He is eligible") : console.log("Not eligible")



 let marks=100;
 marks==100 ? console.log("topper") : console.log("not a topper")










